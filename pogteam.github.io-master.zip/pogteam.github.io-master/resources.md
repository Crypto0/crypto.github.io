---
layout: default
title: Resources
permalink: resources.html
---

# Resources

## General practice

* http://ctftime.org/
* http://hackthebox.eu/
* https://www.vulnhub.com/
* http://pwnable.kr/
* https://hack.me
* http://root-me.org/

### Reverse Engineering

* The Shellcoder's Handbook
* Hacking: The Art of Exploitation
* https://exploit-exercises.com/nebula
* http://pwnable.kr/

### Web

* The Web Application Hacker's Handbook
* https://www.owasp.org/index.php/Web_Application_Security_Testing_Cheat_Sheet
* https://www.owasp.org/index.php/OWASP_Broken_Web_Applications_Project
* https://xss-game.appspot.com/
* https://hack.me/t/XSS

### Crypto

* http://cryptopals.com/
* https://www.coursera.org/learn/crypto

[back](./)
