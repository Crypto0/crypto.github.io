---
layout: default
title: Conduct
permalink: conduct.html
---

# Conduct

1. Be respectful. Always. With everyone.

2. Commitment. It is ok to skip some contests or even to stay out for a while, but what is the point to be on the team if you never participate?

3. Be helpful. The whole point of the team is to help each other. Do it.

4. Communicate. Talk with the team, both during contests or in the meantime. We all wanna have a great time after all :)

5. Share. Saw a good learning resource? Share it. Though about a new evil trick? Share it. Developped a new tool? Share it. You got the point.

[back](./)
